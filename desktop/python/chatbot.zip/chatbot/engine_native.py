"""chatbot/engine_native.py - direct ctypes bridge to libmathengine.

Calls the same CoreEngine::compute() used by the JavaFX client and the
Spring Boot server, but loads the shared library directly via ctypes.
This lets the chatbot compute results with no server/JVM dependency at all.
"""
from __future__ import annotations
import ctypes
import os
import platform
import threading

_LIB_NAMES = {
        "Linux":    "libmathengine.so",
        "Darwin":   "libmathengine.dylib",
        "Windows":  "mathengine.dll",
}


class EngineUnavailable(Exception):
    """Raised when libmathengine cannot be located or loaded."""


def _candidate_paths() -> list[str]:
    lib_name = _LIB_NAMES.get(platform.system(), "libmathengine.so")
    here = os.path.dirname(os.path.abspath(__file__))
    # here = .../desktop/python/chatbot -> project root is three levels up
    project_root = os.path.abspath(os.path.join(here, "..", "..", ".."))
    cwd = os.getcwd()
    return [
            os.path.join(project_root, "build", "lib", lib_name),
            os.path.join(cwd, "build", "lib", lib_name),
            os.path.join(cwd, "..", "build", "lib", lib_name),
            lib_name, # last resort: let the OS loader search (LD_LIBRARY_PATH / PATH)
    ]


class _Engine:
    def __init__(self) -> None:
        self._lib: ctypes.CDLL | None = None
        self._lock = threading.Lock()

    def _load(self) -> ctypes.CDLL:
        if self._lib is not None:
            return self._lib
        with self._lock:
            if self._lib is not None:
                return self._lib
            last_err: Exception | None = None
            for path in _candidate_paths():
                try:
                    lib = ctypes.CDLL(path)
                except OSError as e:
                    last_err = e
                    continue
                lib.mathengine_compute.argtypes = [ctypes.c_char_p, ctypes.c_int]
                lib.mathengine_compute.restype = ctypes.c_void_p
                lib.mathengine_free.argtypes = [ctypes.c_void_p]
                lib.mathengine_free.restype = None
                lib.mathengine_version.argtypes = []
                lib.mathengine_version.restype = ctypes.c_void_p
                self._lib = lib
                return lib
            detail = f" ({last_err})" if last_err is not None else ""
            raise EngineUnavailable(
                    "Could not load libmathengine - build the C++ engine first "
                    f"(./build.sh or .\\build.ps1).{detail}"
            ) from last_err

    def compute(self, expression: str, precision_flag: int) -> str:
        lib = self._load()
        ptr = lib.mathengine_compute(expression.encode("utf-8"), int(precision_flag))
        if not ptr:
            raise EngineUnavailable("Engine returned no result (out of memory?)")
        try:
            return ctypes.cast(ptr, ctypes.c_char_p).value.decode("utf-8", errors="replace")
        finally:
            lib.mathengine_free(ptr)

    def version(self) -> str:
        lib = self._load()
        ptr = lib.mathengine_version()
        if not ptr:
            return "unknown"
        try:
            return ctypes.cast(ptr, ctypes.c_char_p).value.decode("utf-8", errors="replace")
        finally:
            lib.mathengine_free(ptr)


ENGINE = _Engine()
