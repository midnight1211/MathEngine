"""chatbot/io.py — stdin/stdout JSON protocol and HTTP client."""
from __future__ import annotations
import sys, json, urllib.request, urllib.error
from typing import Optional
 
SERVER_URL = "http://localhost:8080"
 
 
# ── Protocol helpers ──────────────────────────────────────────────────────────
def send(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()
 
def send_msg(text: str) -> None:
    send({"type": "message", "text": text})
 
def send_err(text: str) -> None:
    send({"type": "error", "text": text})
 
 
# ── HTTP client ───────────────────────────────────────────────────────────────
def http_post(path: str, body: dict, token: Optional[str] = None) -> Optional[dict]:
    data = json.dumps(body).encode()
    hdrs = {"Content-Type": "application/json"}
    if token:
        hdrs["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(SERVER_URL + path, data=data, headers=hdrs, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode())
        except Exception:
            return {"ok": False, "error": f"HTTP {e.code}"}
    except Exception:
        return None
 
def http_get(path: str, token: Optional[str] = None) -> Optional[dict]:
    hdrs = {}
    if token:
        hdrs["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(SERVER_URL + path, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None
