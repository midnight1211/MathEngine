"""chatbot/handler.py — main message handler, corrections, chaining, error diagnosis."""
from __future__ import annotations
import re
from chatbot.io import send_msg, send
from chatbot.engine_native import ENGINE, EngineUnavailable
from chatbot.state import STATE, ConvTurn
from chatbot.validation import ValidationError, validate
from chatbot.intent import parse_intent, intent_to_expr, resolve_clarification, _clean, _var
from chatbot.formatting import format_steps
from chatbot.explain import EXPLAIN_REQ, EXPLANATIONS, explain
from chatbot.conversation import (
    conversational_reply, handle_history, HISTORY_R, CLEAR_R
)
 
# ── Correction patterns ───────────────────────────────────────────────────────
CORRECTION_PAT = re.compile(
    r'^(?:no,?\s+)?(?:i\s+meant|actually|sorry,?\s+i\s+meant|correction[:,]?|'
    r'wait,?\s+(?:i\s+meant|make\s+that))\s+(.+)', re.I)
 
# ── Chaining ──────────────────────────────────────────────────────────────────
CHAIN_SPLIT = re.compile(r'\s+(?:then|and then|,?\s*after that)\s+', re.I)
 
# ── Error diagnosis ───────────────────────────────────────────────────────────
_ERROR_RULES = [
    (r'undefined variable[:\s]+(\w+)',
     lambda m, _: f"The engine couldn't resolve **{m.group(1)}**. Check all variables are intended."),
    (r'unexpected (?:token|character)',
     lambda m, _: "Syntax issue — often mismatched brackets or an unsupported operator. Try rewriting with `^` for powers, `*` for multiplication."),
    (r'unknown.*operation[:\s]+(\w+)',
     lambda m, _: f"**{m.group(1)}** isn't a recognized operation. Type **help** to see supported ops."),
    (r'singular|determinant.*0|no inverse',
     lambda m, _: "That matrix is **singular** (determinant 0) — it has no inverse."),
    (r'dimension|size mismatch',
     lambda m, _: "**Dimension mismatch** — for multiplication, columns of A must equal rows of B."),
    (r'requires at least (\d+) data points',
     lambda m, _: f"This method needs at least **{m.group(1)} data points**."),
    (r'must be square',
     lambda m, _: "This operation requires a **square matrix** (n×n)."),
    (r'does not converge|failed to converge',
     lambda m, _: "Didn't converge — try a different starting point or interval."),
]
 
def diagnose_engine_error(raw: str, intent: dict) -> str:
    for pattern, fn in _ERROR_RULES:
        m = re.search(pattern, raw, re.I)
        if m:
            return f"⚠ {fn(m, intent)}\n\n*(engine said: {raw.strip()})*"
    return f"⚠ {raw.strip()}"
 
 
# ── Engine call ───────────────────────────────────────────────────────────────
def compute(engine_expr: str) -> tuple[bool, str]:
    try:
        result = ENGINE.compute(engine_expr, 0)
    except EngineUnavailable as e:
        return False, f"⚠ {e}"
    if result.startswith("ERROR:"):
        return False, f"⚠ Engine: {result[len('ERROR:'):].strip()}"
    return True, result

 
 
# ── Correction ────────────────────────────────────────────────────────────────
def try_correction(text: str) -> dict | None:
    m = CORRECTION_PAT.match(text.strip())
    if not m or STATE.last_intent is None:
        return None
    correction = m.group(1).strip()
    patched = dict(STATE.last_intent)
 
    swap = re.search(r'([-\d.]+)\s+(?:not|instead\s+of)\s+([-\d.]+)', correction, re.I)
    if swap:
        new_val, old_val = swap.group(1), swap.group(2)
        for k in ("a", "b", "n", "point", "order"):
            if str(patched.get(k, "")) == old_val:
                patched[k] = new_val
        if old_val in patched.get("expr", ""):
            patched["expr"] = patched["expr"].replace(old_val, new_val)
        return patched
 
    m2 = re.search(r'(upper|lower)\s+bound\s+(?:should\s+be|is|to)\s+([-\w.]+)', correction, re.I)
    if m2:
        patched["b" if m2.group(1).lower() == "upper" else "a"] = m2.group(2)
        return patched
 
    m3 = re.search(r'(?:use|the\s+expression\s+(?:should\s+be|is))\s+(.+)', correction, re.I)
    if m3:
        patched["expr"] = _clean(m3.group(1))
        return patched
 
    if re.search(r'[+\-*/^]', correction):
        patched["expr"] = _clean(correction)
        return patched
    return None
 
 
# ── Chaining ──────────────────────────────────────────────────────────────────
def split_chain(text: str) -> list[str] | None:
    parts = CHAIN_SPLIT.split(text)
    return [p.strip() for p in parts if p.strip()] if len(parts) >= 2 else None
 
def _run_chain(steps: list[str], raw_text: str) -> None:
    send_msg(f"🔗 Running {len(steps)} chained steps…")
    STATE.push(ConvTurn("user", raw_text))
    for i, step in enumerate(steps, 1):
        resolved = STATE.resolve_pronouns(step)
        intent = parse_intent(resolved) or {"op":"compute","expr":resolved}
        if STATE.pending_intent is not None:
            send_msg(f"Step {i}/{len(steps)}: {STATE.pending_q}")
            return
        try:
            validate(intent)
        except ValidationError as ve:
            send_msg(f"⚠ Step {i}/{len(steps)} failed validation: {ve}")
            return
        engine_expr = intent_to_expr(intent)
        ok, raw_result = compute(engine_expr)
        if not ok:
            send_msg(f"⚠ Step {i}/{len(steps)} failed: {diagnose_engine_error(raw_result, intent)}")
            return
        formatted = format_steps(raw_result, intent)
        send_msg(f"**Step {i}/{len(steps)}:** {formatted}")
        STATE.push(ConvTurn("user", step, engine_expr, raw_result))
        STATE.push(ConvTurn("bot", formatted))
        STATE.last_op = intent.get("op"); STATE.last_intent = intent
    send_msg("✓ Chain complete.")
 
 
# ── Single intent runner ──────────────────────────────────────────────────────
def _run_intent(intent: dict, raw_text: str, text: str) -> None:
    if "_precomputed" in intent:
        if intent.get("_error"):
            reply = f"⚠ {intent['_error']}"
        else:
            reply = f"**{intent['expr']}**  →  {intent['_precomputed']}"
        STATE.push(ConvTurn("user", raw_text)); STATE.push(ConvTurn("bot", reply))
        STATE.last_op = "convert"; STATE.last_intent = intent
        send_msg(reply)
        return
 
    try:
        validate(intent)
    except ValidationError as ve:
        reply = f"⚠ **Before I compute:** {ve}"
        STATE.push(ConvTurn("user", raw_text)); STATE.push(ConvTurn("bot", reply))
        send_msg(reply)
        return
 
    engine_expr = intent_to_expr(intent)
    if engine_expr != text and intent.get("op") not in ("compute",):
        send_msg(f"Computing: `{engine_expr}`")
 
    ok, raw_result = compute(engine_expr)
    formatted = format_steps(raw_result, intent) if ok else diagnose_engine_error(raw_result, intent)
    inline_save = STATE.try_save(raw_text, raw_result) if ok else None
 
    STATE.push(ConvTurn("user", raw_text, engine_expr, raw_result if ok else ""))
    STATE.push(ConvTurn("bot", formatted))
    if ok:
        STATE.last_op = intent.get("op"); STATE.last_intent = intent
 
    send_msg(formatted)
    if inline_save:
        STATE.push(ConvTurn("bot", inline_save)); send_msg(inline_save)
 
    if ok and intent.get("op") in ("compute","derivative","taylor","indef_integral") \
            and re.search(r'\bx\b', intent.get("expr","")) \
            and "=" not in intent.get("expr",""):
        send_msg("💡 Want me to graph that? Just say \"graph it\".")
 
 
# ── Main message handler ──────────────────────────────────────────────────────
def handle_message(raw_text: str) -> None:
    # Explain mode
    if EXPLAIN_REQ.match(raw_text.strip()):
        exp = explain(raw_text)
        STATE.push(ConvTurn("user", raw_text))
        if exp:
            STATE.push(ConvTurn("bot", exp)); send_msg(exp)
        else:
            topics = ", ".join(sorted(EXPLANATIONS.keys())).replace("_"," ")
            msg = f"I don't have an explanation for that yet. Topics I can explain: {topics}"
            STATE.push(ConvTurn("bot", msg)); send_msg(msg)
        return
 
    # Correction
    corr = try_correction(raw_text)
    if corr is not None:
        STATE.pending_intent = None; STATE.pending_q = None
        _run_intent(corr, raw_text, raw_text)
        return
 
    text = STATE.resolve_pronouns(raw_text)
 
    # Conversational short-circuits
    conv = conversational_reply(text)
    if conv is not None:
        STATE.push(ConvTurn("user", raw_text)); STATE.push(ConvTurn("bot", conv))
        send_msg(conv)
        return
 
    if HISTORY_R.search(text):
        msg = handle_history()
        STATE.push(ConvTurn("user", raw_text)); send_msg(msg)
        return
 
    # Graph push
    if re.search(r'\b(?:graph|plot)\s+(?:that|it|this)\b', text, re.I):
        last_e = STATE.last_intent.get("expr") if STATE.last_intent else None
        msg = f"📈 Sent `{last_e}` to the Graph tab." if last_e else "I don't have a previous expression to graph yet."
        if last_e: send({"type":"graph","expr":last_e})
        STATE.push(ConvTurn("user", raw_text)); STATE.push(ConvTurn("bot", msg))
        send_msg(msg)
        return
 
    # Save variable (standalone)
    last_result = STATE.last_result()
    if last_result and re.search(r'\b(?:save|store|call|name)\b', text, re.I):
        msg = STATE.try_save(text, last_result)
        if msg:
            STATE.push(ConvTurn("user", raw_text)); STATE.push(ConvTurn("bot", msg))
            send_msg(msg)
            return
 
    # Resolve pending clarification
    if STATE.pending_intent is not None:
        complete = resolve_clarification(text, STATE.pending_intent)
        if complete is None or "_slot" in complete:
            STATE.push(ConvTurn("user", raw_text)); return
        STATE.pending_intent = None; STATE.pending_q = None
        _run_intent(complete, raw_text, text)
        return
 
    # Chained request
    chain = split_chain(text)
    if chain is not None:
        _run_chain(chain, raw_text); return
 
    # Fresh intent parse
    intent = parse_intent(text) or {"op":"compute","expr":text}
    if STATE.pending_intent is not None:
        STATE.push(ConvTurn("user", raw_text)); send_msg(STATE.pending_q); return
 
    _run_intent(intent, raw_text, text)
