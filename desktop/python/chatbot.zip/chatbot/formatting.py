"""chatbot/formatting.py - educational result formatting and convergence tables (Feature B)."""
from __future__ import annotations
import re
from chatbot.validation import _parse_matrix_dims


def format_steps(result_raw: str, intent: dict) -> str:
    op    = intent.get("op", "")
    expr  = intent.get("expr", "")
    var   = intent.get("var", "x")
    a     = intent.get("a", "")
    b     = intent.get("b", "")
    lines = result_raw.strip().splitlines()

    if op in ("newton_raphson", "bisection", "secant"):
        return _format_newton(result_raw, intent)

    if op in ("integral", "romberg", "numerical_int"):
        out = [f"**∫ {expr} d{var}** from **{a}** to **{b}**", ""]
        sym = next((l for l in lines if "=" in l and not l.startswith("Method")), "")
        meth = next((l for l in lines if l.lower().startswith("method")), "")
        num  = next((l for l in lines if re.search(r'[-+]?\d+\.?\d*([eE][-+]?\d+)?', l) and l != sym), "")
        if sym: out.append(f"**Symbolic result:** {sym}")
        if num and num != sym: out.append(f"**Numeric value:**   {num}")
        if meth: out.append(f"*{meth}*")
        if not out[2:]: out += lines
        return "\n".join(out)

    if op in ("derivative", "partial", "nth_derivative"):
        n_label = f" (order {intent.get('n',1)})" if op == "nth_derivative" else ""
        out = [f"**d/d{var}{n_label}  [{expr}]**", ""]
        for line in lines:
            if line.strip(): out.append(f"  = {line.strip()}")
        return "\n".join(out)

    if op in ("det","inverse","eigenvalues","lu","qr","svd","null_space","rref"):
        dims = _parse_matrix_dims(intent.get("matrix",""))
        header = f"**{op.upper().replace('_',' ')}** of {dims[0]}×{dims[1]} matrix" if dims else f"**{op.upper().replace('_',' ')}**"
        return header + "\n\n" + result_raw.strip()

    if op in ("taylor","maclaurin"):
        out = [f"**Taylor series** of `{expr}` around **{intent.get('point',0)}** (order {intent.get('order',5)})", ""]
        return "\n".join(out + lines)

    if op == "solve_equation":
        return "\n".join([f"**Solving** `{expr} = 0` for **{var}**", ""] + lines)

    if op == "solve_linsys":
        return "\n".join(["**Solving the system** (via row reduction):", ""] + lines)

    if op in ("normal_pdf","normal_cdf"):
        kind = "density" if op == "normal_pdf" else "cumulative probability"
        return "\n".join([f"**Normal distribution** N(μ={intent.get('a')}, σ={intent.get('b')}) — {kind} at x={intent.get('point')}", ""] + lines)

    if op in ("binomial_pmf","binomial_cdf"):
        kind = "P(X = k)" if op == "binomial_pmf" else "P(X ≤ k)"
        return "\n".join([f"**Binomial(n={intent.get('n')}, p={intent.get('p',0.5)})** — {kind} at k={intent.get('point')}", ""] + lines)

    if op in ("poisson_pmf","poisson_cdf"):
        kind = "P(X = k)" if op == "poisson_pmf" else "P(X ≤ k)"
        return "\n".join([f"**Poisson(λ={intent.get('a')})** — {kind} at k={intent.get('point')}", ""] + lines)

    if op in ("linear_reg","poly_reg"):
        kind = "Linear" if op == "linear_reg" else f"Polynomial (degree {intent.get('n',2)})"
        return "\n".join([f"**{kind} regression**", ""] + lines)

    return result_raw.strip()


def _format_newton(raw: str, intent: dict) -> str:
    op  = intent.get("op","newton_raphson")
    var = intent.get("var","x")
    expr = intent.get("expr","f(x)")
    method = {"newton_raphson":"Newton-Raphson","bisection":"Bisection","secant":"Secant"}.get(op,"Iterative method")
    if op == "bisection":
        start = f"interval [{intent.get('a','?')}, {intent.get('b','?')}]"
    elif op == "secant":
        start = f"x₀ = {intent.get('a','?')}, x₁ = {intent.get('b','?')}"
    else:
        start = f"x₀ = {intent.get('a','?')}"

    header = ["iter","x_n","f(x_n)","error"]
    rows = []
    for line in raw.splitlines():
        nums = re.findall(r'[-+]?\d+\.?\d*(?:[eE][-+]?\d+)?', line)
        if len(nums) >= 3: rows.append(nums[:4])

    root_line = next((l for l in raw.splitlines() if re.search(r'root|converge', l, re.I)), "")
    out = [f"**{method}** for `f({var}) = {expr}`, {start}", ""]

    if rows:
        col_w = [max(len(h), max((len(r[i]) for r in rows if i < len(r)), default=0)) for i,h in enumerate(header)]
        def row_str(r): return "  ".join(str(c).ljust(col_w[i]) for i,c in enumerate(r))
        out += ["```", row_str(header), "-" * (sum(col_w) + 2*len(col_w))]
        for r in rows: out.append(row_str(r))
        out.append("```")
    else:
        out += raw.strip().splitlines()

    if root_line:
        out += ["", f"✓ **{root_line.strip()}**"]
    return "\n".join(out)
