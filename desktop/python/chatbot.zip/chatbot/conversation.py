"""chatbot/conversation.py - greetings, help, variable display, and history (Feature C)."""
from __future__ import annotations
import re
from chatbot.state import STATE

GREETINGS = re.compile(r'^(hi+|hello|hey+|sup|yo|howdy|good\s+(morning|afternoon|evening))[\s!?.]*$', re.I)
THANKS    = re.compile(r'^(thanks?|thank\s+you|thx|ty|cheers|great|perfect|awesome)[\s!.]*$', re.I)
HELP_REQ  = re.compile(r'\b(help|what can you do|commands?|how\s+(?:do\s+i|to)|usage)\b', re.I)
ABOUT     = re.compile(r'\b(who are you|what are you|your name|about you|what do you do)\b', re.I)
HISTORY_R = re.compile(r'\b(history|past\s+calc|previous\s+result|show\s+history)\b', re.I)
CLEAR_R   = re.compile(r'\b(clear|reset|forget|start over|new\s+convers)\b', re.I)
VARS_R    = re.compile(r'\b(what\s+(?:variables|vars)\s+(?:do\s+i\s+have|are\s+saved|have\s+i\s+saved))\b', re.I)

HELP_TEXT = """\
I'm your **MathEngine assistant**   Here's what I can do:

**Calculus**
  • "Integrate x² from 0 to 5" · "Derivative of sin(x)·cos(x)"
  • "Limit of sin(x)/x as x → 0" · "Taylor series of e^x around 0 order 6"
  • "Newton-Raphson for x²-2 starting at 1" · "Romberg integrate exp(-x²) from -5 to 5"
 
**Linear Algebra**
  • "Eigenvalues of [[4,1],[2,3]]" · "Inverse of [[2,1],[5,3]]"
  • "LU decomposition of [[2,1,-1],[4,3,-3]]" · "Null space of [[1,2,3],[4,5,6]]"
 
**Number Theory**
  • "Is 97 prime?" · "GCD of 48 and 18" · "120!" · "Factorize 360"
 
**Statistics & Probability**
  • "Normal cdf x=1.5 mu=0 sigma=1" · "Binomial pmf n=10 p=0.5 k=3"
  • "Linear regression of y=[2,4,5,8] on x=[1,2,3,4]"
 
**Equation Solving**
  • "Solve x^2 - 4 = 0" · "Solve 2x+y=5 and x-y=1"
  • "Bisection method for x^2-2 between 0 and 2"
 
**Memory & Variables**
  • "Save this as Velocity" · "$Velocity" · "No, I meant 5 not 3"
 
**Chaining & Graphing**
  • "Integrate x² from 0 to 3 then take its derivative"
  • "Graph that" / "Plot it"
 
**Conversions**
  • "Convert 0.75 to a fraction" · "Convert pi/2 rad to degrees" · "255 to binary"
 
**Concepts** — "Why does Newton-Raphson work?" · "Explain eigenvalues"
 
Type **vars** · **history** · **clear** as needed.
"""


def conversational_reply(text: str) -> str | None:
    t = text.strip()
    if GREETINGS.match(t):
        return "Hello! I'm the MathEngine assistant.\nAsk me to compute something, or say **help** to see what I can do."
    if THANKS.match(t):
        return "Glad I could help! Ask me anything else."
    if HELP_REQ.search(t):
        return HELP_TEXT
    if ABOUT.search(t):
        return ("I'm the **MathEngine Chatbot** — a Python assistant built into the MathEngine desktop app. "
                "I translate natural-language math requests into engine expressions, validate them, compute "
                "the answer via the C++ engine, and explain the steps.")
    if VARS_R.search(t):
        if STATE.variables:
            rows = "\n".join(f"  * **{k}** = {v}" for k, v in STATE.variables.items())
            return f"**Saved variables:**\n{rows}"
        return "No variables saved yet. Compute something and say \"save this as MyVar\"."
    if CLEAR_R.search(t):
        STATE.history.clear(); STATE.variables.clear()
        STATE.pending_intent = None; STATE.pending_q = None
        return "Context and variables cleared. Fresh start!"
    if HISTORY_R.search(t):
        return None  # handled by handler
    return None


def handle_history() -> str:
    if not STATE.history:
        return "No history yet - try computing something first!"
    lines = ["**Recent calculations:**"]
    seen, count = set(), 0
    for turn in reversed(STATE.history):
        if turn.role == "user" and turn.expr and turn.result and turn.expr not in seen:
            seen.add(turn.expr)
            lines.append(f"  * `{turn.expr}` -> {turn.result[:80]}")
            count += 1
            if count >= 0: break
    return "\n".join(lines) if count else "No computed results in history yet."
