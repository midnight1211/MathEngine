"""chatbot/state.py - ConvTurn, ConvState, and the global STATE singleton."""
from __future__ import annotations
import re
from dataclasses import dataclass, field

MAX_HISTORY = 20


@dataclass
class ConvTurn:
    role:   str
    text:   str
    expr:   str = ""
    result: str = ""


@dataclass
class ConvState:
    history:        list[ConvTurn]  = field(default_factory=list)
    variables:      dict[str, str]  = field(default_factory=dict)
    pending_intent: dict | None     = None
    pending_q:      str  | None     = None
    last_op:        str  | None     = None
    last_intent:    dict | None     = None
    last_raw_text:  str  | None     = None
    auth_token:     str  | None     = None

    def last_result(self) -> str | None:
        for t in reversed(self.history):
            if t.result:
                return t.result
        return None

    def last_expr(self) -> str | None:
        for t in reversed(self.history):
            if t.expr:
                return t.expr
        return None

    def push(self, turn: ConvTurn) -> None:
        self.history.append(turn)
        if len(self.history) > MAX_HISTORY * 2:
            self.history = self.history[-(MAX_HISTORY * 2):]

    def resolve_pronouns(self, text: str) -> str:
        t = text
        t = re.sub(
            r'\$([A-Za-z_]\w*)',
            lambda m: self.variables.get(m.group(1), m.group(0)),
            t
        )
        t = re.sub(
            r'\b(?:the\s+(?:result|value)\s+(?:called|named|stored\s+as)\s+)([A-Za-z_]\w*)',
            lambda m: self.variables.get(m.group(1), m.group(0)),
            t, flags=re.I
        )
        last = self.last_result()
        if last:
            t = re.sub(
                r'\b(the\s+(?:previous|last)\s+(?:result|answer|value)|'
                r'the\s+answer|that\s+result|it\b|that\b)',
                last, t, flags=re.I
            )
        last_e = self.last_expr() or ""
        if "[[" in last_e:
            mat = re.search(r'\[\[.*?\]\]', last_e)
            if mat:
                t = re.sub(
                    r'\b(?:the\s+)?(?:previous|last)\s+matrix\b',
                    mat.group(0), t, flags=re.I
                )
        mul = re.search(
            r'multiply\s+(?:the\s+)?(?:previous\s+(?:matrix|result)|it)\s+by\s+([0-9.]+)',
            t, re.I
        )
        if mul and "[[" in last_e:
            mat_s = re.search(r'\[\[.*?\]\]', last_e)
            if mat_s:
                return f"la:scale|{mat_s.group(0)}|{mul.group(1)}"
        return t

    def try_save(self, text: str, result: str) -> str | None:
        m = re.search(
            r'\b(?:save|store|call|name|label)\s+(?:this|it|the\s+result)?\s*(?:result)?\s*as\s+["\']?([A-Za-z_]\w*)["\']?',
            text, re.I
        )
        if m:
            name = m.group(1)
            self.variables[name] = result
            return f"✓ Saved as **{name}**. Use `${name}` or say \"the result called {name}\" to reference it later."
        return None


STATE = ConvState()
