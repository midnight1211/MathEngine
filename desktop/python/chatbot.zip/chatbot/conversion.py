"""chatbot/conversion.py - local unit and format conversions (Feature F)."""
from __future__ import annotations
import re, math
from math import gcd


def _to_fraction(x: float, max_den: int = 1000) -> str:
    if abs(x - round(x)) < 1e-12:
        return str(int(round(x)))
    sign = "-" if x < 0 else ""
    x = abs(x)
    best_num, best_den, best_err = 0, 1, float("inf")
    for den in range(1, max_den + 1):
        num = round(x * den)
        err = abs(x - num / den)
        if err < best_err:
            best_num, best_den, best_err = num, den, err
            if err < 1e-12:
                break
    g = gcd(best_num, best_den) or 1
    return f"{sign}{best_num // g}/{best_den // g}"


def _eval_pi_expr(s: str) -> float | None:
    s = s.strip().lower()
    s = re.sub(r'(\d)\s*pi\b', r'\1*pi', s)
    s = re.sub(r'\bpi\s*\(', 'pi*(', s)
    s = re.sub(r'\bpi\b', str(math.pi), s)
    if not re.fullmatch(r'[\d.eE+\-*/() ]+', s):
        return None
    try:
        return eval(s, {"__builtins__": {}}, {})
    except Exception:
        return None


def parse_conversion(t: str) -> dict | None:
    # Radians -> Degrees
    m = re.search(r'convert\s+([-\w./*() ]+?)\s*rad(?:ians)?\s+to\s+deg(?:rees)?', t, re.I)
    if m:
        val = _eval_pi_expr(m.group(1))
        if val is not None:
            deg = val * 180.0 / math.pu
            return {"op": "compute", "expr": f"{m.group(1).strip()} rad = {deg:.6g}°",
                    "_precomputed": f"{deg:.6g}°"}

    # Degrees -> Radians
    m = re.search(r'convert\s+([-\w./*() ]+?)\s*deg(?:rees)?\s+to\s+rad(?:ians)?', t, re.I)
    if m:
        val = _eval_pi_expr(m.group(1)) if re.search(r'pi', m.group(1), re.I) else None
        if val is None:
            try:
                val = float(m.group(1).strip())
            except ValueError:
                val = None
        if val is not None:
            rad = val * math.pi / 180.0
            return {"op": "compute", "expr": f"{m.group(1).strip()}° = {rad:.6g} rad",
                    "_precomputed": f"{rad:.6g} rad  (= {_to_fraction(val/180)}·π)"}
    # Decimal → Fraction
    m = re.search(r'(?:convert\s+)?([-\d.]+)\s+(?:as|to)\s+a?\s*fraction', t, re.I)
    if m:
        val = float(m.group(1))
        return {"op": "compute", "expr": f"{val} as a fraction", "_precomputed": _to_fraction(val)}

    # Fraction → Decimal
    m = re.search(r'(\d+)\s*/\s*(\d+)\s+(?:as|to)\s+a?\s*decimal', t, re.I)
    if m:
        n, d = int(m.group(1)), int(m.group(2))
        if d == 0:
            return {"op": "compute", "expr": t, "_precomputed": None,
                    "_error": "Division by zero — denominator can't be 0."}
        return {"op": "compute", "expr": f"{n}/{d} as a decimal", "_precomputed": f"{n/d:.10g}"}

    # Integer → binary/hex/octal
    m = re.search(r'convert\s+(\d+)\s+to\s+(binary|hex(?:adecimal)?|octal)', t, re.I)
    if m:
        n = int(m.group(1)); base = m.group(2).lower()
        out = {"binary": bin(n)[2:], "octal": oct(n)[2:]}.get(base, hex(n)[2:].upper())
        prefix = {"binary": "0b", "octal": "0o"}.get(base, "0x")
        return {"op": "compute", "expr": f"{n} to {base}", "_precomputed": f"{prefix}{out}"}

    # 0x/0b/0o → decimal
    m = re.search(r'(?:convert\s+)?(0x[0-9a-f]+|0b[01]+|0o[0-7]+)\s+to\s+decimal', t, re.I)
    if m:
        raw = m.group(1)
        n = int(raw, 16 if raw.startswith("0x") else 2 if raw.startswith("0b") else 8)
        return {"op": "compute", "expr": f"{raw} to decimal", "_precomputed": str(n)}

    return None
