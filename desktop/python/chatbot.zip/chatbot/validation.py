"""chatbot/validation.py - pre-flight domain validation (Feature D)."""
from __future__ import annotations
import re


class ValidationError(Exception):
    pass


def _parse_matrix_dims(s: str) -> list[int]:
    rows = re.findall(r'\[([^\[\]]+)\]', s)
    if not rows:
        return []
    col_counts = [len(r.split(',')) for r in rows]
    return [len(rows), col_counts[0]] if col_counts else []


def validate(intent: dict) -> None:
    op   = intent.get("op", "")
    expr = intent.get("expr", "")
    a    = intent.get("a")
    b    = intent.get("b")
    mat  = intent.get("matrix", "")
    mat2 = intent.get("matrix2", "")
 
    # Integral bounds
    if op in ("integral", "romberg", "numerical_int") and a is not None and b is not None:
        try:
            fa, fb = float(a), float(b)
            if fa == fb:
                raise ValidationError(
                    f"The lower and upper bounds are both **{a}** — the integral over "
                    f"a zero-width interval is 0. Did you mean different limits?"
                )
            if fa > fb:
                raise ValidationError(
                    f"Lower bound **{a}** is greater than upper bound **{b}**. "
                    f"I'll swap them, but please confirm: did you mean ∫ from {b} to {a}?"
                )
        except ValueError:
            pass
 
    # Expression safety
    if expr:
        if re.search(r'/\s*0(?!\d)', expr):
            raise ValidationError(
                "The expression contains a **division by zero** (`/0`). "
                "Please check your formula."
            )
        m = re.search(r'\b(?:log|ln)\s*\(\s*(-?\d+\.?\d*)\s*\)', expr)
        if m and float(m.group(1)) <= 0:
            v = int(float(m.group(1)))
            raise ValidationError(
                f"**ln({v})** is undefined — the natural log requires a positive argument. "
                f"Did you mean `ln(|{v}|)` or a different value?"
            )
        m = re.search(r'\bsqrt\s*\(\s*(-\d+\.?\d*)\s*\)', expr)
        if m:
            raise ValidationError(
                f"**sqrt({m.group(1)})** is not real — square root of a negative number "
                f"is undefined in ℝ. Did you intend complex mode?"
            )
        if re.search(r'\btan\s*\(\s*(?:pi/2|1\.5707)', expr):
            raise ValidationError(
                "**tan(π/2)** is undefined (vertical asymptote). "
                "Check whether your expression is evaluated at or near π/2."
            )
 
    # Matrix dimension checks
    if mat:
        dims = _parse_matrix_dims(mat)
        if dims:
            rows, cols = dims
            if op in ("det", "inverse", "eigen", "eigenvalues", "null", "qr", "lu", "svd"):
                if rows != cols:
                    raise ValidationError(
                        f"**{op}** requires a square matrix, but the matrix you provided "
                        f"is **{rows}×{cols}**. Please supply an n×n matrix."
                    )
            if op == "inverse" and rows == 2:
                inner = re.findall(r'(-?[\d.]+)', mat)
                if len(inner) == 4:
                    try:
                        a_, b_, c_, d_ = map(float, inner)
                        if abs(a_ * d_ - b_ * c_) < 1e-12:
                            raise ValidationError(
                                "The 2×2 matrix has **determinant 0** — it is singular "
                                "and has no inverse."
                            )
                    except ValueError:
                        pass
            if op in ("multiply", "matmul") and mat2:
                dims2 = _parse_matrix_dims(mat2)
                if dims2:
                    r2, c2 = dims2
                    if cols != r2:
                        raise ValidationError(
                            f"Matrix dimension mismatch: a **{rows}×{cols}** matrix cannot "
                            f"be multiplied by a **{r2}×{c2}** matrix. "
                            f"The inner dimensions must match ({cols} ≠ {r2})."
                        )
 
    # Factorial
    n = intent.get("n")
    if n is not None and op in ("factorial", "permutation", "combination"):
        try:
            ni = int(n)
            if ni < 0:
                raise ValidationError(
                    f"**{op}({ni})** is undefined — factorial is only defined for non-negative integers."
                )
            if ni > 10000:
                raise ValidationError(
                    f"**{ni}!** is astronomically large. Are you sure you want n={ni}?"
                )
        except (ValueError, TypeError):
            pass
 
    # Probability
    if op in ("binomial_pmf", "binomial_cdf"):
        p = intent.get("p")
        if p is not None:
            try:
                if not (0.0 <= float(p) <= 1.0):
                    raise ValidationError(f"Probability **p={p}** must be between 0 and 1.")
            except (ValueError, TypeError):
                pass
        k, n_ = intent.get("point"), intent.get("n")
        if k is not None and n_ is not None:
            try:
                if int(k) > int(n_):
                    raise ValidationError(
                        f"**k={k}** can't exceed **n={n_}** — you can't have more successes than trials."
                    )
                if int(k) < 0:
                    raise ValidationError(f"**k={k}** must be non-negative.")
            except (ValueError, TypeError):
                pass
 
    if op in ("normal_pdf", "normal_cdf"):
        sigma = intent.get("b")
        if sigma is not None:
            try:
                if float(sigma) <= 0:
                    raise ValidationError(
                        f"**σ={sigma}** must be positive — std deviation can't be zero or negative."
                    )
            except (ValueError, TypeError):
                pass
 
    if op in ("poisson_pmf", "poisson_cdf"):
        lam = intent.get("a")
        if lam is not None:
            try:
                if float(lam) <= 0:
                    raise ValidationError(f"**λ={lam}** must be positive for a Poisson distribution.")
            except (ValueError, TypeError):
                pass
 
    if op in ("linear_reg", "poly_reg"):
        xs = intent.get("a", ""); ys = intent.get("b", "")
        nx = xs.count(',') + 1 if xs.strip('[] ') else 0
        ny = ys.count(',') + 1 if ys.strip('[] ') else 0
        if nx and ny and nx != ny:
            raise ValidationError(
                f"x has **{nx}** values but y has **{ny}** — regression needs matching lengths."
            )
        if nx and nx < 2:
            raise ValidationError("Regression needs at least 2 data points.")
 
    if op == "bisection":
        try:
            if float(intent.get("a", 0)) == float(intent.get("b", 0)):
                raise ValidationError("Bisection needs two **distinct** endpoints.")
        except (ValueError, TypeError):
            pass
 
    if op in ("fft", "ifft"):
        samples = [s for s in re.split(r'[,\s]+', expr.strip()) if s]
        if not samples:
            raise ValidationError("FFT needs a list of numeric samples, e.g. `fft of 1,1,0,-1,-1,-1,0,1`.")
        try:
            [float(s) for s in samples]
        except ValueError:
            raise ValidationError("All FFT samples must be plain numbers (no variables or expressions).")
