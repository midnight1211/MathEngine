"""chatbot/explain.py - conceptual explanation mode (Feature E)."""
from __future__ import annotations
import re
from chatbot.state import STATE

EXPLAIN_REQ = re.compile(
        r'^(?:why|explain|what does it mean|what is the (?:intuition|idea)\s+(?:behind|of))\b',
        re.I)

EXPLANATIONS = {
        "integral": (
        "An **integral** ∫f(x)dx finds the *accumulated area* between a curve and "
        "the x-axis. Think of slicing the region under the curve into infinitely "
        "many thin rectangles and summing their areas — the integral is the limit "
        "of that sum as the rectangles get infinitely thin (a Riemann sum)."
    ),
    "derivative": (
        "A **derivative** measures *instantaneous rate of change* — the slope of "
        "the tangent line at a point. It's the limit of the average rate of change "
        "(Δy/Δx) as the interval Δx shrinks to zero."
    ),
    "limit": (
        "A **limit** describes the value a function *approaches* as the input gets "
        "arbitrarily close to some point — even if the function isn't defined "
        "exactly there. It formalizes 'getting closer and closer' with precision."
    ),
    "eigenvalues": (
        "**Eigenvalues** λ of a matrix A are the scalars where Av = λv for some "
        "nonzero vector v (the eigenvector). Geometrically, A stretches/shrinks v "
        "by exactly λ without rotating it — eigenvectors are the matrix's 'natural axes'."
    ),
    "inverse": (
        "The **inverse** of a matrix A, written A⁻¹, is the matrix that 'undoes' "
        "A's transformation: A·A⁻¹ = I (the identity). It only exists when A is "
        "square and its determinant is nonzero."
    ),
    "determinant": (
        "The **determinant** measures how much a matrix scales area (2D) or volume (3D+) "
        "— and its sign tells you whether the transformation flips orientation. "
        "A determinant of 0 means the matrix squashes space into a lower dimension."
    ),
    "taylor": (
        "A **Taylor series** approximates a function near a point using a polynomial "
        "built from the function's derivatives at that point: "
        "f(x) ≈ f(a) + f'(a)(x−a) + f''(a)(x−a)²/2! + ... "
        "More terms = better approximation, especially close to a."
    ),
    "newton_raphson": (
        "**Newton-Raphson** finds roots of f(x)=0 by repeatedly following the "
        "tangent line down to the x-axis: x_{n+1} = x_n − f(x_n)/f'(x_n). "
        "Each step typically roughly doubles the number of correct digits."
    ),
    "gcd": (
        "The **GCD** (greatest common divisor) is the largest integer that divides "
        "both numbers evenly. The Euclidean algorithm finds it efficiently: gcd(a,b) = gcd(b, a mod b)."
    ),
    "fourier": (
        "A **Fourier series** decomposes a periodic function into sines and cosines "
        "of different frequencies — every wiggly periodic shape is built from pure tones layered together."
    ),
    "markov": (
        "A **Markov chain** models a system moving between states probabilistically, "
        "where the next state depends only on the current state. The **steady-state** "
        "is the distribution where it stops changing."
    ),
    "rank": (
        "The **rank** of a matrix is the number of linearly independent rows (or columns) "
        "— the dimension of the space its columns actually span."
    ),
    "null_space": (
        "The **null space** of A is the set of all vectors v where Av = 0 — "
        "directions A completely collapses. Its dimension (nullity) measures information loss."
    ),
    "linear_reg": (
        "**Linear regression** finds the line minimizing the sum of squared distances "
        "to data points (least squares). R² measures how well the line explains variation in y."
    ),
    "bisection": (
        "**Bisection** finds a root of f(x)=0 by halving an interval [a,b] where f changes sign. "
        "The IVT guarantees a root inside. Slower than Newton-Raphson but always converges."
    ),
    "normal_pdf": (
        "The **normal distribution** is the classic bell curve. The PDF gives relative "
        "likelihood density; the CDF gives P(X ≤ x)."
    ),
    "binomial_pmf": (
        "The **binomial distribution** models successes in n trials with probability p each. "
        "P(X=k) = C(n,k)·pᵏ·(1−p)ⁿ⁻ᵏ."
    ),
    "fft": (
        "The **FFT** computes frequency content of a discrete signal in O(n log n) "
        "using Cooley-Tukey divide-and-conquer — splitting into even/odd halves recursively."
    ),
}

SYNONYMS = {
        "linear_reg":   [r'\bregression\b', r'\bleast squares\b'],
        "mornal_pdg":   [r'\bnormal distribution\b', r'\bbell curve\b', r'\bgaussian\b'],
        "binomial_pmf": [r'\bbinomial distribution\b', r'\bbinomial\b'],
        "bisection":    [r'\bbisection method\b'],
        "fft":          [r'\bfast fourier\b', r'\bfft\b'],
}


def explain(topic_hint: str) -> str | None:
    t = topic_hint.lower()
    if re.search(r'\b(that|this|it)\b', t) and STATE.last_op:
        key = STATE.last_op
        if key in EXPLANATIONS:
            return f"**Why {key.replace('_', ' ')} works:**\n\n{EXPLANATIONS[key]}"
    for key, pats in SYNONYMS.items():
        if any(re.search(p, t) for p in pats):
            return f"**Why {key.replace('_', ' ')} works:**\n\n{EXPLANATIONS[key]}"
    for key, text in EXPLANATIONS.items():
        spaced = key.replace("_", " ")
        if re.search(rf'\b{spaced}\b', t) or re.search(rf'\b{key}\b', t):
            return f"**Why {spaced} works:**\n\n{text}"
    return None
