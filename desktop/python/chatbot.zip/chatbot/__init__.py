"""
chatbot — MathEngine Python chatbot package.
 
Submodules:
    io           — stdin/stdout JSON protocol and HTTP client
    state        — ConvTurn, ConvState, STATE singleton
    validation   — domain validation before engine calls (Feature D)
    conversion   — unit and format conversions (Feature F)
    intent       — NL intent parsing and intent_to_expr (Feature A)
    explain      — conceptual explanations (Feature E)
    formatting   — step-by-step educational formatting (Feature B)
    conversation — greetings, help text, history (Feature C)
    handler      — main message dispatcher (Features A–F combined)
 
Entry point: chatbot_main.py (project root)
"""
