"""chatbot/intent.py - NL intent parsing, expression building, clarification (Feature A)."""
from __future__ import annotations
import re
from chatbot.state import STATE
from chatbot.conversion import parse_conversion

# --- Helpers ---------------------------------------------------------------------------
def _clean(s: str) -> str:
    return re.sub(r'^(?:the\s+function\s+|expression\s+|equation\s+formula\s+)?', '', s, flags=re.I).strip().rstrip('.,;')

def _var(s: str) -> str:
    m = re.search(r'\bd([a-zA-Z])\b', s)
    if m: return m.group(1)
    for v in ['x', 'y', 't', 'z', 'n']:
        if re.search(rf'\b{v}\b', s): return v
    return 'x'

def _num(s: str) -> str:
    s = s.strip()
    s = re.sub(r'\binfinity\b', 'inf', s, flags=re.I)
    s = re.sub(r'\b-\s*infinity\b', '-inf', s, flags=re.I)
    s = re.sub(r'\bπ\b', 'pi', s)
    return s

def _equations_to_matrix(eq_strings: list[str]) -> str | None:
    var_order: list[str] = []
    parsed_eqs = []
    for eq in eq_strings:
        if '=' not in eq: return None
        lhs, rhs = eq.split('=', 1)
        terms = re.findall(r'([+-]?\s*\d*\.?\d*)\s*([a-zA-Z])?', lhs)
        coeffs: dict[str, float] = {}
        for coef_s, var_s in terms:
            coef_s = coef_s.replace(' ', '')
            if not coef_s and not var_s: continue
            if var_s:
                coef = 1.0 if coef_s in ('', '+') else -1.0 if coef_s == '-' else (float(coef_s) if coef_s else 0)
                try: coef = float(coef_s) if coef_s not in ('', '+', '-') else coef
                except ValueError: continue
                coeffs[var_s] = coeffs.get(var_s, 0.0) + coef
                if var_s not in var_order: var_order.append(var_s)
        try: rhs_val = float(rhs.strip())
        except ValueError: return None
        parsed_eqs.append((coeffs, rhs_val))
    if not var_order or len(parsed_eqs) < len(var_order): return None
    rows = []
    for coeffs, rhs_val in parsed_eqs:
        row = [str(coeffs.get(v, 0.0)) for v in var_order] + [str(rhs_val)]
        rows.append("[" + ",".join(row) + "]")
    return "[" + ",".join(rows) + "]"

# --- Clarification slots ---------------------------------------------------------------
CLARIFY_QUESTIONS = {
        "missing_lower":       "What is the **lower bound** (lower limit of integration)?",
    "missing_upper":       "What is the **upper bound** (upper limit of integration)?",
    "missing_var":         "What **variable** should I integrate / differentiate with respect to? (e.g. x, t, y)",
    "missing_expr":        "What is the **expression** or function you'd like to work with?",
    "missing_point":       "Around what **point** (e.g. x=0) should I expand the series?",
    "missing_order":       "What **order** of approximation would you like? (e.g. 5)",
    "missing_matrix":      "Please provide the **matrix** in the form [[a,b],[c,d]].",
    "missing_n":           "What value of **n** would you like to use?",
    "missing_steps":       "How many **steps** (iterations) should the simulation run?",
    "missing_bounds_both": "What are the **lower and upper bounds**? (e.g. 0 and 1, or -inf and inf)",
}

def _ask(slot: str, partial: dict, original_text: str) -> str:
    STATE.pending_intent = {**partial, "_slot": slot, "_original": original_text}
    STATE.pending_q = CLARIFY_QUESTIONS.get(slot, "Could you clarify?")
    return STATE.pending_q

# --- Intent -> engine expression -------------------------------------------------------
def intent_to_expr(intent: dict) -> str:
    op    = intent.get("op", "")
    expr  = intent.get("expr", "")
    var   = intent.get("var", "x")
    a     = intent.get("a", "")
    b     = intent.get("b", "")
    mat   = intent.get("matrix", "")
    mat2  = intent.get("matrix2", "")
    n     = intent.get("n", "")
    steps = intent.get("steps", "5")
    order = intent.get("order", "5")
    point = intent.get("point", "0")
    
    # gcd/lcm carry their two operands inside expr as "a,b"
    pair  = [p.strip() for p in str(expr).split(",")] + ["0", "0"]

    dispatch = {
        "integral":       lambda: f"definite_int[{expr}, {var}, {a}, {b}]",
        "indef_integral": lambda: f"integrate[{expr}, {var}]",
        "derivative":     lambda: f"diff[{expr}, {var}]",
        "partial":        lambda: f"partial[{expr}, {var}]",
        "nth_derivative": lambda: f"diff[{expr}, {var}, {n}]",
        "limit":          lambda: f"limit[{expr}, {var}, {point}]",
        "taylor":         lambda: f"taylor[{expr},{point},{order}]",
        "maclaurin":      lambda: f"maclaurin[{expr},{order}]",
        "fourier":        lambda: f"fourier[{expr},{a},{b},{order}]",
        "romberg":        lambda: f"romberg[{expr}|{var}|{a}|{b}]",
        "numerical_int":  lambda: f"numerical_int[{expr}|{var}|{a}|{b}]",
        "newton_raphson": lambda: f'na:newton|{{"f":"{expr}","x":"{var}","x0":{a},"tol":1e-10,"maxIter":50}}',
        "gradient":       lambda: f"gradient[{expr}, x, y]",
        "curl":           lambda: f"curl[{expr}, x, y, z]",
        "divergence":     lambda: f"div[{expr}, x, y, z]",
        "det":            lambda: f"la:determinant|{mat}",
        "inverse":        lambda: f"la:inv|{mat}",
        "eigenvalues":    lambda: f"la:eigen|{mat}",
        "null_space":     lambda: f"la:null|{mat}",
        "transpose":      lambda: f"la:matrix_transpose|{mat}",
        "rref":           lambda: f"la:rref|{mat}",
        "rank":           lambda: f"la:rank|{mat}",
        "trace":          lambda: f"la:trace|{mat}",
        "lu":             lambda: f"la:lu|{mat}",
        "qr":             lambda: f"la:qr|{mat}",
        "svd":            lambda: f"la:svd|{mat}",
        "matmul":         lambda: f"la:mul|{mat}|{mat2}",
        "scale":          lambda: f"la:scale|{mat}|{n}",
        "solve_system":   lambda: f"la:solve|{mat}|{mat2}",
        "factorial":      lambda: f'dm:permutations|{{"n":{n},"r":{n}}}',
        "gcd":            lambda: f'nt:gcd|{{"a":{pair[0]},"b":{pair[1]}}}',
        "lcm":            lambda: f'nt:lcm|{{"a":{pair[0]},"b":{pair[1]}}}',
        "prime_test":     lambda: f'nt:is_prime|{{"n":{n}}}',
        "factorize":      lambda: f'nt:prime_factors|{{"n":{n}}}',
        "fibonacci":      lambda: f'nt:fibonacci|{{"n":{n}}}',
        "mean":           lambda: f'stat:mean|{{"x":"{expr}"}}',
        "std":            lambda: f'stat:stddev|{{"x":"{expr}"}}',
        "variance":       lambda: f'stat:variance|{{"x":"{expr}"}}',
        "median":         lambda: f'stat:median|{{"x":"{expr}"}}',
        "normal_pdf":     lambda: f'stat:normal_pdf|{{"x":{point},"mu":{a},"sigma":{b}}}',
        "normal_cdf":     lambda: f'stat:normal_cdf|{{"x":{point},"mu":{a},"sigma":{b}}}',
        "binomial_pmf":   lambda: f'stat:binomial_pmf|{{"n":{n},"p":{intent.get("p",0.5)},"k":{point}}}',
        "binomial_cdf":   lambda: f'stat:binomial_cdf|{{"n":{n},"p":{intent.get("p",0.5)},"k":{point}}}',
        "poisson_pmf":    lambda: f'stat:poisson_pmf|{{"lambda":{a},"k":{point}}}',
        "poisson_cdf":    lambda: f'stat:poisson_cdf|{{"lambda":{a},"k":{point}}}',
        "t_cdf":          lambda: f'stat:t_cdf|{{"x":{point},"df":{n}}}',
        "chisq_cdf":      lambda: f'stat:chisq_cdf|{{"x":{point},"df":{n}}}',
        "linear_reg":     lambda: f'stat:linear_reg|{{"x":"{a}","y":"{b}"}}',
        "poly_reg":       lambda: f'stat:poly_reg|{{"x":"{a}","y":"{b}","degree":{n or 2}}}',
        "markov":         lambda: f"markov[{mat}|{expr}|{steps}]",
        "bisection":      lambda: f'na:bisection|{{"f":"{expr}","x":"{var}","a":{a},"b":{b},"tol":1e-10,"maxIter":100}}',
        "secant":         lambda: f'na:secant|{{"f":"{expr}","x":"{var}","x0":{a},"x1":{b},"tol":1e-10,"maxIter":50}}',
        "solve_equation": lambda: f'na:all_roots|{{"f":"{expr}","x":"{var}","a":{intent.get("a",-50)},"b":{intent.get("b",50)},"subs":200}}',
        "solve_linsys":   lambda: f"la:rref|{mat}",
        "laplace":        lambda: f'de:laplace|{{"expr":"{expr}","var":"{var}","s":"s"}}',
        "inv_laplace":    lambda: f'de:inverse_laplace|{{"expr":"{expr}","var":"s","t":"t"}}',
        "fft":            lambda: f"fft[{expr}]",
        "ifft":           lambda: f"ifft[{expr}]",
        "dot_product":    lambda: f"dot_product[{mat}|{mat2}]",
        "cross_product":  lambda: f"cross_product[{mat}|{mat2}]",
        "convex_hull":    lambda: f"convex_hull[{expr}]",
        "compute":        lambda: expr,
    }
    fn = dispatch.get(op)
    return fn() if fn else expr

# --- parse_intent ----------------------------------------------------------------------
def parse_intent(text: str) -> dict | None:
    t = text.strip()

    conv = parse_conversion(t)
    if conv is not None:
        return conv

    # Definite integral
    m = re.search(r'(?:integrat(?:e|ion\s+of)|area\s+under|∫)\s+(.+?)(?:\s+d[a-zA-Z])?\s+from\s+([^\s]+)\s+to\s+([^\s,]+)', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"integral","expr":expr,"var":_var(expr),"a":_num(m.group(2)),"b":_num(m.group(3))}

    m = re.search(r'(?:integrat(?:e|ion\s+of)|indefinite\s+integral\s+of|antiderivative\s+of)\s+(.+?)(?:\s+d([a-zA-Z]))?$', t, re.I)
    if m:
        expr = _clean(m.group(1)); var = m.group(2) or _var(expr)
        return _ask("missing_bounds_both", {"op":"integral","expr":expr,"var":var}, text)

    m = re.search(r'integral\s+of\s+(.+?)\s+from\s+([^\s]+)\s+to\s+([^\s,]+)', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"integral","expr":expr,"var":_var(expr),"a":_num(m.group(2)),"b":_num(m.group(3))}

    # Derivative
    m = re.search(r'(?:derivative\s+of|differentiate|diff(?:erentiate)?)\s+(.+?)(?:\s+with\s+respect\s+to\s+([a-zA-Z]))?(?:\s+(?:at|evaluated\s+at)\s+([^\s]+))?$', t, re.I)
    if m:
        return {"op":"derivative","expr":_clean(m.group(1)),"var":m.group(2) or _var(m.group(1))}

    m = re.search(r'(\d+(?:st|nd|rd|th)?|first|second|third|fourth|fifth)\s+derivative\s+of\s+(.+?)(?:\s+with\s+respect\s+to\s+([a-zA-Z]))?$', t, re.I)
    if m:
        word = m.group(1).lower()
        n = {"first":"1","second":"2","third":"3","fourth":"4","fifth":"5"}.get(word, re.sub(r'\D','',word) or "1")
        expr = _clean(m.group(2))
        return {"op":"nth_derivative","expr":expr,"var":m.group(3) or _var(expr),"n":n}

    m = re.search(r'partial\s+(?:derivative\s+of\s+)?(.+?)\s+with\s+respect\s+to\s+([a-zA-Z])', t, re.I)
    if m:
        return {"op":"partial","expr":_clean(m.group(1)),"var":m.group(2)}

    # Limit
    m = re.search(r'limit\s+of\s+(.+?)\s+as\s+([a-zA-Z])\s+(?:approaches|->|→|goes\s+to)\s+([^\s,]+)', t, re.I)
    if m:
        return {"op":"limit","expr":_clean(m.group(1)),"var":m.group(2),"point":_num(m.group(3))}

    # Taylor / Maclaurin
    m = re.search(r'taylor\s+(?:series\s+(?:of|for)\s+)?(.+?)(?:\s+(?:around|at|about|centered\s+at)\s+([^\s,]+))?(?:\s+(?:order|degree|to)\s+(\d+))?$', t, re.I)
    if m:
        expr = _clean(m.group(1)); point = _num(m.group(2)) if m.group(2) else None; order = m.group(3) or "5"
        if point is None:
            return _ask("missing_point", {"op":"taylor","expr":expr,"order":order}, text)
        return {"op":"taylor","expr":expr,"point":point,"order":order}

    m = re.search(r'maclaurin\s+(?:series\s+(?:of|for)\s+)?(.+?)(?:\s+order\s+(\d+))?$', t, re.I)
    if m:
        return {"op":"maclaurin","expr":_clean(m.group(1)),"order":m.group(2) or "5"}

    # Fourier
    m = re.search(r'fourier\s+(?:series\s+(?:of|for)\s+)?(.+?)(?:\s+on\s+\[?([^\],]+),\s*([^\]]+)\]?)?(?:\s+(?:order|terms)\s+(\d+))?$', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"fourier","expr":expr,"a":_num(m.group(2)) if m.group(2) else "-pi","b":_num(m.group(3)) if m.group(3) else "pi","order":m.group(4) or "5"}

    # Numerical integration / Newton-Raphson
    m = re.search(r'(?:romberg|numerical(?:ly)?\s+integrat(?:e|ion))\s+(.+?)\s+from\s+([^\s]+)\s+to\s+([^\s,]+)', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"romberg","expr":expr,"var":_var(expr),"a":_num(m.group(2)),"b":_num(m.group(3))}

    m = re.search(r'(?:newton[- ]raphson|newton\'s\s+method)\s+(?:for\s+|on\s+)?(.+?)(?:\s+(?:starting\s+at|from|x0\s*=|initial\s+guess\s*=?)\s*([^\s,]+))?$', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"newton_raphson","expr":expr,"var":_var(expr),"a":m.group(2) or "1"}

    # Linear algebra
    mat_pat = re.search(r'(\[\[.+?\]\])', t)
    mat_s = mat_pat.group(1) if mat_pat else ""
    for kw, op in [
        (r'\b(?:det(?:erminant)?)\s+of\b', "det"),
        (r'\binverse\s+of\b', "inverse"),
        (r'\beigenvalue[s]?\s+of\b', "eigenvalues"),
        (r'\bnull\s+space\s+of\b', "null_space"),
        (r'\btranspose\s+of\b', "transpose"),
        (r'\b(?:rref|row\s+reduce)\s+of\b', "rref"),
        (r'\b(?:rank)\s+of\b', "rank"),
        (r'\b(?:trace)\s+of\b', "trace"),
        (r'\blu\s+(?:decomp(?:osition)?\s+of\b|factori[sz]ation)', "lu"),
        (r'\bqr\s+decomp(?:osition)?\s+of\b', "qr"),
        (r'\bsvd\s+(?:of\b|decomp)', "svd"),
    ]:
        if re.search(kw, t, re.I):
            return {"op":op,"matrix":mat_s} if mat_s else _ask("missing_matrix", {"op":op}, text)

    m2 = re.findall(r'\[\[.+?\]\]', t)
    if len(m2) >= 2 and re.search(r'\bmultiply|product\b', t, re.I):
        return {"op":"matmul","matrix":m2[0],"matrix2":m2[1]}
    m = re.search(r'multiply\s+(?:the\s+)?matrix\s+(.+?)\s+by\s+([0-9.]+)', t, re.I)
    if m: return {"op":"scale","matrix":m.group(1),"n":m.group(2)}
    if re.search(r'\bsolve\b.+\[\[', t, re.I) and len(m2) >= 2:
        return {"op":"solve_system","matrix":m2[0],"matrix2":m2[1]}

    # Number theory
    m = re.search(r'\b(?:factorial\s+of\s+|(\d+)\s*!)\s*(\d+)?', t, re.I)
    if m:
        n = m.group(1) or m.group(2)
        if not n:
            m2b = re.search(r'factorial\s+of\s+(\d+)', t, re.I)
            n = m2b.group(1) if m2b else None
        if n: return {"op":"factorial","n":n}
    m = re.search(r'\bgcd\s+(?:of\s+)?(\d+)\s+(?:and|,)\s+(\d+)', t, re.I)
    if m: return {"op":"gcd","expr":f"{m.group(1)},{m.group(2)}"}
    m = re.search(r'\blcm\s+(?:of\s+)?(\d+)\s+(?:and|,)\s+(\d+)', t, re.I)
    if m: return {"op":"lcm","expr":f"{m.group(1)},{m.group(2)}"}
    m = re.search(r'(?:is\s+)?(\d+)\s+prime\??$', t, re.I)
    if m: return {"op":"prime_test","n":m.group(1)}
    m = re.search(r'(?:prime\s+)?factoris[ez]\s+(\d+)', t, re.I)
    if m: return {"op":"factorize","n":m.group(1)}
    m = re.search(r'\bfibonacci\b.{0,10}(\d+)', t, re.I)
    if m: return {"op":"fibonacci","n":m.group(1)}

    # Statistics / Probability
    m = re.search(r'\bmean\s+of\s+([\d,\s.]+)', t, re.I)
    if m: return {"op":"mean","expr":m.group(1).strip()}
    m = re.search(r'\b(?:std(?:dev)?|standard\s+deviation)\s+of\s+([\d,\s.]+)', t, re.I)
    if m: return {"op":"std","expr":m.group(1).strip()}
    m = re.search(r'\bvariance\s+of\s+([\d,\s.]+)', t, re.I)
    if m: return {"op":"variance","expr":m.group(1).strip()}
    m = re.search(r'\bmedian\s+of\s+([\d,\s.]+)', t, re.I)
    if m: return {"op":"median","expr":m.group(1).strip()}

    m = re.search(r'normal\s+(pdf|cdf|density|probability)?.*?(?:x\s*=\s*|at\s+)([-\d.]+).*?(?:mu|mean)\s*=\s*([-\d.]+).*?(?:sigma|std)\s*=\s*([-\d.]+)', t, re.I)
    if m:
        op = "normal_cdf" if (m.group(1) or "").lower() in ("cdf","probability") else "normal_pdf"
        return {"op":op,"point":_num(m.group(2)),"a":_num(m.group(3)),"b":_num(m.group(4))}
    m = re.search(r'probability\s+(?:that\s+)?x\s*[<≤]\s*([-\d.]+).*?n\s*\(\s*([-\d.]+)\s*,\s*([-\d.]+)\s*\)', t, re.I)
    if m: return {"op":"normal_cdf","point":_num(m.group(1)),"a":_num(m.group(2)),"b":_num(m.group(3))}

    m = re.search(r'binomial\s+(pmf|cdf)?.*?n\s*=\s*(\d+).*?p\s*=\s*([\d.]+).*?k\s*=\s*(\d+)', t, re.I)
    if m:
        op = "binomial_cdf" if (m.group(1) or "").lower() == "cdf" else "binomial_pmf"
        return {"op":op,"n":m.group(2),"p":m.group(3),"point":m.group(4)}
    m = re.search(r'p\s*\(\s*x\s*=\s*(\d+)\s*\)\s+for\s+binomial\s*\(\s*(\d+)\s*,\s*([\d.]+)\s*\)', t, re.I)
    if m: return {"op":"binomial_pmf","point":m.group(1),"n":m.group(2),"p":m.group(3)}

    m = re.search(r'poisson\s+(pmf|cdf)?.*?(?:lambda|λ)\s*=\s*([\d.]+).*?k\s*=\s*(\d+)', t, re.I)
    if m:
        op = "poisson_cdf" if (m.group(1) or "").lower() == "cdf" else "poisson_pmf"
        return {"op":op,"a":m.group(2),"point":m.group(3)}
    m = re.search(r'p\s*\(\s*x\s*=\s*(\d+)\s*\)\s+for\s+poisson\s*\(\s*([\d.]+)\s*\)', t, re.I)
    if m: return {"op":"poisson_pmf","a":m.group(2),"point":m.group(1)}

    m = re.search(r't\s+cdf.*?x\s*=\s*([-\d.]+).*?df\s*=\s*(\d+)', t, re.I)
    if m: return {"op":"t_cdf","point":m.group(1),"n":m.group(2)}
    m = re.search(r'chi[- ]?(?:square|sq)\s+cdf.*?x\s*=\s*([-\d.]+).*?df\s*=\s*(\d+)', t, re.I)
    if m: return {"op":"chisq_cdf","point":m.group(1),"n":m.group(2)}

    m = re.search(r'(linear|polynomial|poly)?\s*regression\s+(?:of\s+)?y\s*=\s*(\[[\d,.\s-]+\])\s+(?:on|vs\.?|against)\s+x\s*=\s*(\[[\d,.\s-]+\])(?:\s+degree\s+(\d+))?', t, re.I)
    if m:
        op = "poly_reg" if (m.group(1) or "").lower().startswith("poly") else "linear_reg"
        return {"op":op,"a":m.group(3),"b":m.group(2),"n":m.group(4) or "2"}

    m = re.search(r'markov.{0,30}(\[\[.+?\]\]|\d[\d,;.]+).{0,30}(\[\d.+?\]).{0,10}(\d+)', t, re.I)
    if m: return {"op":"markov","matrix":m.group(1),"expr":m.group(2).strip('[]'),"steps":m.group(3)}

    # Root finding
    m = re.search(r'bisection\s+(?:method\s+)?(?:for|on)\s+(.+?)\s+(?:between|from)\s+([^\s]+)\s+(?:and|to)\s+([^\s,]+)', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"bisection","expr":expr,"var":_var(expr),"a":_num(m.group(2)),"b":_num(m.group(3))}
    m = re.search(r'secant\s+(?:method\s+)?(?:for|on)\s+(.+?)\s+(?:starting\s+at|with\s+(?:initial\s+)?(?:points|guesses))\s+([^\s]+)\s+(?:and|,)\s+([^\s,]+)', t, re.I)
    if m:
        expr = _clean(m.group(1))
        return {"op":"secant","expr":expr,"var":_var(expr),"a":_num(m.group(2)),"b":_num(m.group(3))}

    # Systems of equations / single equation
    is_multi = re.search(r'\bsystem\b', t, re.I) or len(re.findall(r'=', t)) >= 2
    if is_multi:
        eqs = re.findall(r'([-+]?\d*\.?\d*\s*[a-zA-Z]\s*[-+]\s*\d*\.?\d*\s*[a-zA-Z]?\s*=\s*[-\d.]+)', t)
        if len(eqs) >= 2:
            mat = _equations_to_matrix(eqs)
            if mat: return {"op":"solve_linsys","matrix":mat}
    if not is_multi:
        m = re.search(r'solve\s+(?:for\s+([a-zA-Z])\s+(?:in|:)\s+)?(.+?)\s*=\s*0\b', t, re.I)
        if m:
            return {"op":"solve_equation","expr":_clean(m.group(2)),"var":m.group(1) or _var(m.group(2))}
        m = re.search(r'solve\s+(?:for\s+([a-zA-Z])\s+(?:in|:)\s+)?(.+?)\s*=\s*([^=]+)$', t, re.I)
        if m and not re.search(r'\[\[', t):
            lhs, rhs = _clean(m.group(2)), m.group(3).strip()
            expr = f"({lhs})-({rhs})" if rhs != "0" else lhs
            return {"op":"solve_equation","expr":expr,"var":m.group(1) or _var(lhs)}

    # FFT
    m = re.search(r'(?:fft|fourier\s+transform)\s+(?:of\s+)?(\[[\d,.\s-]+\]|[\d,.\s-]+)', t, re.I)
    if m and not re.search(r'series', t, re.I):
        return {"op":"fft","expr":m.group(1).strip('[] ')}
    m = re.search(r'(?:ifft|inverse\s+fft)\s+(?:of\s+)?(\[[\d,.\s-]+\]|[\d,.\s-]+)', t, re.I)
    if m: return {"op":"ifft","expr":m.group(1).strip('[] ')}

    # Laplace
    m = re.search(r'\blaplace\s+(?:transform\s+of\s+)?(.+)', t, re.I)
    if m and not re.search(r'inverse|inv\b', t, re.I):
        return {"op":"laplace","expr":_clean(m.group(1)),"var":"t"}
    m = re.search(r'\b(?:inverse\s+laplace|ilaplace)\s+(?:transform\s+of\s+)?(.+)', t, re.I)
    if m: return {"op":"inv_laplace","expr":_clean(m.group(1)),"var":"s"}

    # Geometry
    m = re.search(r'dot\s+product\s+of\s+(.+?)\s+and\s+(.+)', t, re.I)
    if m: return {"op":"dot_product","matrix":m.group(1),"matrix2":m.group(2)}
    m = re.search(r'cross\s+product\s+of\s+(.+?)\s+and\s+(.+)', t, re.I)
    if m: return {"op":"cross_product","matrix":m.group(1),"matrix2":m.group(2)}

    # Generic arithmetic
    if re.search(r'[+\-*/^!%]|\bsqrt\b|\bsin\b|\bcos\b|\btan\b|\blog\b|\bln\b|\babs\b', t, re.I):
        return {"op":"compute","expr":t}

    return None


# --- Clarification resulution ----------------------------------------------------------
def resolve_clarification(answer: str, partial: dict) -> dict | None:
    slot = partial.get("_slot")
    a = answer.strip()

    if slot == "missing_lower":
        partial["a"] = _num(a); partial.pop("_slot"); partial.pop("_original","")
        if not partial.get("b"):
            return _ask("missing_upper", partial, a)
    elif slot == "missing_upper":
        partial["b"] = _num(a); partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_bounds_both":
        nums = re.findall(r'[-+]?(?:\d+\.?\d*|pi|inf)', a, re.I)
        if len(nums) >= 2:
            partial["a"] = _num(nums[0]); partial["b"] = _num(nums[1])
        elif len(nums) == 1:
            partial["a"] = _num(nums[0])
            return _ask("missing_upper", partial, a)
        else:
            return _ask("missing_bounds_both", partial, a)
        partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_var":
        m = re.search(r'[a-zA-Z]', a)
        partial["var"] = m.group(0) if m else "x"
        partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_expr":
        partial["expr"] = _clean(a); partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_point":
        partial["point"] = _num(a); partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_order":
        partial["order"] = a; partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_matrix":
        m = re.search(r'(\[\[.+?\]\])', a)
        partial["matrix"] = m.group(1) if m else a
        partial.pop("_slot"); partial.pop("_original","")
    elif slot in ("missing_n",):
        partial["n"] = a; partial.pop("_slot"); partial.pop("_original","")
    elif slot == "missing_steps":
        partial["steps"] = a; partial.pop("_slot"); partial.pop("_original","")

    if "_slot" in partial:
        return None
    return partial
